const loginForm = document.getElementById('loginForm');
const errorMessage = document.getElementById('errorMessage');

if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        errorMessage.classList.add('hidden');

        try {
            // Substitua pela URL da API do auth-service em ambiente de deploy/staging
            const response = await fetch('https://api-gateway-ou-auth-service.url/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, password })
            });

            if (!response.ok) {
                throw new Error('E-mail ou senha inválidos.');
            }

            const data = await response.json();
            
            // Armazenando o token de acesso de forma segura para as próximas requisições
            localStorage.setItem('questify_access_token', data.accessToken);
            localStorage.setItem('questify_refresh_token', data.refreshToken);

            // Redireciona para a página principal da aplicação
            window.location.href = '/dashboard.html';

        } catch (error) {
            errorMessage.textContent = error.message || 'Erro ao conectar com o servidor.';
            errorMessage.classList.remove('hidden');
        }
    });
}